@echo off
setlocal
cd /d "%~dp0"

echo ================================================
echo Rajasthan Royals - Auction Intelligence Dashboard
echo ================================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON=py -3"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo Python was not found. Install Python 3.10 or newer from https://www.python.org/downloads/
        echo During installation, enable "Add Python to PATH".
        pause
        exit /b 1
    )
    set "PYTHON=python"
)

if not exist ".venv\Scripts\python.exe" (
    echo Creating a project virtual environment...
    %PYTHON% -m venv .venv
    if errorlevel 1 goto failed
)

echo Installing or checking required packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed

echo.
echo Starting dashboard. Keep this window open while using it.
echo Your browser should open at http://localhost:8501
".venv\Scripts\python.exe" -m streamlit run app.py
if errorlevel 1 goto failed
exit /b 0

:failed
echo.
echo Dashboard startup failed. Check the error shown above.
pause
exit /b 1
